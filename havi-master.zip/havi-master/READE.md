# havi

## 步骤定义
1、前端输入用户名（ip），root 密码
2、登录判定 hostname  --正则匹配
3、根据HAVI服务器及特殊环境路由到对应shell脚本
4、设置用户权限  三种：测试，研发，PM
5、添加ansible秘钥，用户无秘钥登录服务器
6、查看Log，log_id 为序列
7、每一步进度

## 数据库定义
存储提交信息    havi_submit_info
Log信息查询     havi_log_info



无法生成新表
python manage.py makemigrations --empty  havi
python manage.py makemigrations
python manage.py migrate