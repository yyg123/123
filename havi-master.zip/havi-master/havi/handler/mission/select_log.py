# coding=utf-8
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
import json
from havi.models import LogInfo


@csrf_exempt
def process(request):
    data = json.loads(request.POST.get('data', ''))

    log_id = data.get('log_id')
    print log_id
    lg = LogInfo.objects.get(log_id = log_id)

    data = {
        "result": "success",
        "lines": lg.log_context
    }

    print data
    return JsonResponse(data)
