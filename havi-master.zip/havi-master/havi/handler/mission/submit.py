# coding=utf-8
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import sys
import paramiko
import re
import socket
from havi.models import SubmitInfo,LogInfo


@csrf_exempt
def process(request):

    data = json.loads(request.POST.get('data'))
    #hostname需要匹配的字符串
    hostname_re = 'ubun'
    # 输入执行命令
    cmd = 'echo xxxcxxxx'

    if data.get("user") == ''  or data.get("password") == ''  or data.get("remote_ip") == '':
        return JsonResponse({"result": "fail", "context": "IP或用户名或密码为空"})

    remote_ip = "192.168.199.162"
    # remote_ip= data.get("remote_ip")
    # 登录判定 hostname - -正则匹配
    # hostname, _, _ = socket.gethostbyaddr(remote_ip)
    # if not re.search(hostname_re, hostname):
    #     return JsonResponse({"result": "fail", "context": "请更改hostname符合一下规则{}".format(hostname_re)})


    # 创建SSH对象
    ssh = paramiko.SSHClient()
    # # 允许连接不在know_hosts文件中的主机
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=remote_ip, port=22, username=data.get('user'), password=data.get('password'))

    stdin, stdout, stderr = ssh.exec_command(cmd)
    result = stdout.read()
    print result
    ssh.close()

    #保存数据库
    si = SubmitInfo(**data)

    si.save()
    lg = LogInfo(log_id=si.id,log_context=result)
    lg.save()

    print lg.log_context
    return JsonResponse({"result": "success", "context":"提交成功,任务ID为 {},结果为{}".format(si.id,lg.log_context)})