from django.db import models

class SubmitInfo(models.Model):
    id = models.AutoField(primary_key=True)
    remote_ip = models.CharField(max_length=100)
    user= models.CharField(max_length=100)
    password= models.CharField(max_length=100)
    node= models.CharField(max_length=100)
    permission= models.CharField(max_length=100)
    config= models.CharField(max_length=100)
    # gmt_create = models.DateTimeField()


class LogInfo(models.Model):
    log_id = models.IntegerField()
    log_context = models.CharField(max_length=1000)
    # gmt_create = models.DateTimeField()